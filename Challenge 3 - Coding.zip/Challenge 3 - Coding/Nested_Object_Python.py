#Test Case 1
# dictionary = {'x':{'y':{'z':'a'}}}

#Test Case 2
dictionary = {'a':{'b':{'c':'d'}}}

userinput = input(f"Please enter a key\n")

keyarry = userinput.split("/")
finalkey = keyarry[-1]


def find_by_key(dictionary, key):
     for k, v in dictionary.items():
         if k == key:
             print(v)
         elif isinstance(v, dict):
              find_by_key(v, key)
	 else:
              print("Key not found in the dictionary")


find_by_key(dictionary, finalkey)
